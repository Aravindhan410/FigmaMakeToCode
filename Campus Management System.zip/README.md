
  # Campus Management System (WIP V.1.0) (Code conversion)

  This is a code bundle for Campus Management System (WIP V.1.0) (Code conversion). The original project is available at https://www.figma.com/design/JJfVRhqdQnnPaV2X1VPEXg/Campus-Management-System--WIP-V.1.0---Code-conversion-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  