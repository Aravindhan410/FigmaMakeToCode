import ExaminationReport from './ExaminationReport';

export default function CollegeStrength() {
  return <ExaminationReport title="College Strength Report" showClose={false} />;
}
