import EditHostellerImport from '../imports/EditHosteller';

export default function EditHosteller() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <div className="w-full">
        <EditHostellerImport />
      </div>
    </div>
  );
}
