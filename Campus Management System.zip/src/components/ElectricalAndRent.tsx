import ElectricalAndRentImport from '../imports/HostelReportsElectricalAndRent';

export default function ElectricalAndRent() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <div className="w-full">
        <ElectricalAndRentImport />
      </div>
    </div>
  );
}
