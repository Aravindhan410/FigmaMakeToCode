import HostelExpenseImport from '../imports/HostelExpense';

export default function HostelExpense() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <div className="w-full">
        <HostelExpenseImport />
      </div>
    </div>
  );
}
