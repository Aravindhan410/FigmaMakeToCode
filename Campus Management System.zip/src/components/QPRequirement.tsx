import ExaminationReport from './ExaminationReport';

export default function QPRequirement() {
  return <ExaminationReport title="QP Requirement Report" showClose={true} />;
}
