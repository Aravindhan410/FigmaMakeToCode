import VehicleReportImport from '../imports/VehicleReport-4020-702';

export default function VehicleReport() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <div className="w-full">
        <VehicleReportImport />
      </div>
    </div>
  );
}
