export default function Rectangle() {
  return <div className="bg-gradient-to-r from-100% from-[#45b7d1] size-full to-0% to-[#ff6b6b] via-50% via-[#4ecdc4]" data-name="Rectangle" />;
}