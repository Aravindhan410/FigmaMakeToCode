export default {
p10aed780: "M12.6666 6.75L7.99992 12L3.33325 6.75",
}
