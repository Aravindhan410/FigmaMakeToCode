export default {
pb7adf00: "M12.6667 6L8 10.6667L3.33333 6",
}
