export default {
p39be50: "M13.3333 4L6 11.3333L2.66667 8",
}
